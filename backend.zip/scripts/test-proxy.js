const { URL } = require('url')
const http = require('http')
const https = require('https')

const BASE = process.env.TEST_BASE || 'http://localhost:5173'

function request(method, path, body) {
  return new Promise((resolve, reject) => {
    try {
      const url = new URL(path, BASE)
      const lib = url.protocol === 'https:' ? https : http
      const opts = {
        method,
        hostname: url.hostname,
        port: url.port || (url.protocol === 'https:' ? 443 : 80),
        path: url.pathname + url.search,
        headers: {
          'Accept': 'application/json'
        }
      }

      let payload = null
      if (body) {
        payload = JSON.stringify(body)
        opts.headers['Content-Type'] = 'application/json'
        opts.headers['Content-Length'] = Buffer.byteLength(payload)
      }

      const req = lib.request(opts, res => {
        let data = ''
        res.on('data', chunk => (data += chunk))
        res.on('end', () => {
          const contentType = res.headers['content-type'] || ''
          if (contentType.includes('application/json')) {
            try {
              const parsed = JSON.parse(data || '{}')
              resolve({ status: res.statusCode, body: parsed })
            } catch (err) {
              resolve({ status: res.statusCode, body: data })
            }
          } else {
            resolve({ status: res.statusCode, body: data })
          }
        })
      })

      req.on('error', reject)
      if (payload) req.write(payload)
      req.end()
    } catch (err) {
      reject(err)
    }
  })
}

async function run() {
  try {
    console.log('Using base:', BASE)

    const product = {
      name: 'Prueba desde script Node',
      description: 'Creado por script de prueba',
      price: 4.99,
      imageUrl: '',
      categoryId: 1,
      stock: 5
    }

    console.log('\nPOST -> /api/products')
    const postRes = await request('POST', '/api/products', product)
    console.log('Status:', postRes.status)
    console.log('Response:', JSON.stringify(postRes.body, null, 2))

    console.log('\nGET -> /api/products')
    const getRes = await request('GET', '/api/products')
    console.log('Status:', getRes.status)
    if (Array.isArray(getRes.body)) {
      console.log('Products count:', getRes.body.length)
    }
    console.log(JSON.stringify(getRes.body, null, 2))
  } catch (err) {
    console.error('Error during test:', err && err.message ? err.message : err)
    process.exitCode = 1
  }
}

run()
