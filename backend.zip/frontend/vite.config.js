import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

// https://vitejs.dev/config/
export default defineConfig({
	plugins: [vue()],
	server: {
		// force Vite to listen on all network interfaces (loopback + LAN)
		// so requests to both `localhost` and the machine IP reach the dev server.
		host: '0.0.0.0',
		port: 5173,
		// keep the overlay enabled so you see errors in the browser during development
		hmr: { overlay: true },

		// Dev proxy: forward /api requests to the backend running on port 3000.
		// This allows the frontend to call /api/* regardless of hostname (localhost or LAN IP)
		// without changing the client code or CORS settings.
		proxy: {
			'/api': {
				target: 'http://localhost:3000',
				changeOrigin: true,
				secure: false,
				// rewrite not necessary because paths match, but kept for clarity
				rewrite: (path) => path
			}
		}
	}
})
