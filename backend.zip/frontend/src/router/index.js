import { createRouter, createWebHistory } from 'vue-router'

// Helper that returns a component which fetches an HTML file from src/views
function htmlView(viewFileName) {
    return {
        name: viewFileName,
        data() {
            return { html: '<p>Cargando...</p>' }
        },
        async mounted() {
            try {
                // Fetch the raw HTML file from the src/views folder
                const res = await fetch(`/src/views/${viewFileName}.html`)
                if (!res.ok) throw new Error('HTTP ' + res.status)
                this.html = await res.text()
            } catch (e) {
                console.error('Error cargando vista', viewFileName, e)
                this.html = '<p>Error al cargar la vista.</p>'
            }
        },
        template: `<div v-html="html"></div>`
    }
}

const Home = () => import('../views/HomeView.vue')
const ProductFromView = () => import('../views/ProductFromView.vue')
const ProductDetailView = () => import('../views/ProductDetailView.vue')
const AboutView = () => import('../views/AboutView.vue')
const CartView = () => import('../views/CartView.vue')
const NotFoundView = () => import('../views/NotFoundView.vue')

const routes = [
    { path: '/', component: Home, name: 'home' },
    { path: '/product/new', component: ProductFromView, name: 'product-new' },
    { path: '/product/:id', component: ProductDetailView, name: 'product-detail' },
    { path: '/about', component: AboutView, name: 'about' },
    { path: '/cart', component: CartView, name: 'cart' },
    { path: '/:pathMatch(.*)*', component: NotFoundView, name: 'not-found' }
]

const router = createRouter({
    history: createWebHistory(),
    routes
})

export default router
