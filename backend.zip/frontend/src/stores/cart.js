// stores/cart.js
import { defineStore } from 'pinia'
import { ref, computed } from 'vue'

export const useCartStore = defineStore('cart', () => {
    // Estado
    const items = ref([])

    // Cargar del localStorage al inicializar
    const loadCart = () => {
        const saved = localStorage.getItem('mercapp-cart')
        if (saved) {
            try {
                items.value = JSON.parse(saved)
            } catch (e) {
                console.error('Error al cargar el carrito:', e)
            }
        }
    }

    // Guardar en localStorage
    const saveCart = () => {
        localStorage.setItem('mercapp-cart', JSON.stringify(items.value))
    }

    // Computed
    const totalItems = computed(() => {
        return items.value.reduce((sum, item) => sum + item.quantity, 0)
    })

    const totalPrice = computed(() => {
        return items.value.reduce((sum, item) => sum + (item.price * item.quantity), 0)
    })

    // Actions
    const addItem = (product, quantity = 1) => {
        const existingItem = items.value.find(item => item.id === product.id)

        if (existingItem) {
            existingItem.quantity += quantity
        } else {
            items.value.push({
                id: product.id,
                name: product.name,
                price: product.price,
                imageUrl: product.imageUrl,
                quantity: quantity
            })
        }

        saveCart()
    }

    const removeItem = (productId) => {
        const index = items.value.findIndex(item => item.id === productId)
        if (index > -1) {
            items.value.splice(index, 1)
            saveCart()
        }
    }

    const updateQuantity = (productId, quantity) => {
        const item = items.value.find(item => item.id === productId)
        if (item) {
            if (quantity <= 0) {
                removeItem(productId)
            } else {
                item.quantity = quantity
                saveCart()
            }
        }
    }

    const clearCart = () => {
        items.value = []
        saveCart()
    }

    // Inicializar
    loadCart()

    return {
        items,
        totalItems,
        totalPrice,
        addItem,
        removeItem,
        updateQuantity,
        clearCart
    }
})
