<script setup>
    import { ref, onMounted } from 'vue'
    import { useRoute, useRouter, RouterLink } from 'vue-router'
    import { useProducts } from '../composables/useProducts'
    import { useCartStore } from '../stores/cart'

    const route = useRoute()
    const router = useRouter()
    const { data: product, loading, error, getProduct, deleteProduct } = useProducts()
    const cartStore = useCartStore()

    const quantity = ref(1)

    onMounted(async () => {
        await getProduct(route.params.id)
    })

    const handleAddToCart = () => {
        if (product.value && quantity.value > 0) {
            cartStore.addItem(product.value, quantity.value)
            alert(`${quantity.value} x ${product.value.name} añadido(s) al carrito`)
        }
    }

    const handleDelete = async () => {
        if (confirm('¿Estás seguro de que deseas eliminar este producto?')) {
            try {
                await deleteProduct(route.params.id)
                alert('Producto eliminado correctamente')
                router.push('/')
            } catch (err) {
                alert('Error al eliminar el producto')
            }
        }
    }

    const incrementQuantity = () => {
        if (product.value && quantity.value < product.value.stock) {
            quantity.value++
        }
    }

    const decrementQuantity = () => {
        if (quantity.value > 1) {
            quantity.value--
        }
    }
</script>

<template>
    <div class="container">
        <RouterLink to="/" class="back-link">
            ← Volver al catálogo
        </RouterLink>

        <div v-if="loading" class="loading-container">
            <div class="spinner"></div>
            <p>Cargando producto...</p>
        </div>

        <div v-else-if="error" class="error-message">
            <p>❌ {{ error }}</p>
            <RouterLink to="/" class="btn btn-primary">
                Volver al inicio
            </RouterLink>
        </div>

        <div v-else-if="product" class="product-detail">
            <div class="product-image-container">
                <img :src="product.imageUrl" :alt="product.name" class="product-image" />
            </div>

            <div class="product-info">
                <h1 class="product-title">{{ product.name }}</h1>

                <div class="product-meta">
                    <span class="product-price">${{ product.price.toFixed(2) }}</span>
                    <span class="product-stock" :class="{ 'out-of-stock': product.stock === 0 }">
                        {{ product.stock > 0 ? `${product.stock} disponibles` : 'Agotado' }}
                    </span>
                </div>

                <p class="product-description">{{ product.description }}</p>

                <div v-if="product.stock > 0" class="quantity-selector">
                    <label>Cantidad:</label>
                    <div class="quantity-controls">
                        <button @click="decrementQuantity" class="qty-btn">-</button>
                        <input v-model.number="quantity" type="number" min="1" :max="product.stock" class="qty-input" />
                        <button @click="incrementQuantity" class="qty-btn">+</button>
                    </div>
                </div>

                <div class="action-buttons">
                    <button @click="handleAddToCart" class="btn btn-primary btn-large" :disabled="product.stock === 0">
                        🛒 Añadir al carrito
                    </button>

                    <RouterLink :to="`/product/${product.id}/edit`" class="btn btn-secondary">
                        ✏️ Editar
                    </RouterLink>

                    <button @click="handleDelete" class="btn btn-danger">
                        🗑️ Eliminar
                    </button>
                </div>
            </div>
        </div>
    </div>
</template>

<style scoped>
    .back-link {
        display: inline-block;
        margin-bottom: 2rem;
        color: var(--primary-color);
        text-decoration: none;
        font-weight: 500;
        transition: transform 0.3s;
    }

    .back-link:hover {
        transform: translateX(-5px);
    }

    .product-detail {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 3rem;
        background: white;
        border-radius: 8px;
        padding: 2rem;
        box-shadow: var(--shadow);
    }

    .product-image-container {
        position: relative;
        width: 100%;
        border-radius: 8px;
        overflow: hidden;
        background: var(--light-color);
    }

    .product-image {
        width: 100%;
        height: auto;
        max-height: 500px;
        object-fit: cover;
    }

    .product-info {
        display: flex;
        flex-direction: column;
        gap: 1.5rem;
    }

    .product-title {
        font-size: 2rem;
        color: var(--dark-color);
        margin: 0;
    }

    .product-meta {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding-bottom: 1rem;
        border-bottom: 2px solid var(--light-color);
    }

    .product-price {
        font-size: 2.5rem;
        font-weight: bold;
        color: var(--secondary-color);
    }

    .product-stock {
        font-size: 1rem;
        padding: 0.5rem 1rem;
        background: var(--secondary-color);
        color: white;
        border-radius: 20px;
        font-weight: 500;
    }

    .product-stock.out-of-stock {
        background: var(--danger-color);
    }

    .product-description {
        font-size: 1.125rem;
        line-height: 1.8;
        color: #555;
    }

    .quantity-selector {
        display: flex;
        align-items: center;
        gap: 1rem;
    }

    .quantity-selector label {
        font-weight: 500;
        font-size: 1.125rem;
    }

    .quantity-controls {
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .qty-btn {
        width: 40px;
        height: 40px;
        border: 2px solid var(--primary-color);
        background: white;
        color: var(--primary-color);
        border-radius: 4px;
        font-size: 1.25rem;
        font-weight: bold;
        cursor: pointer;
        transition: all 0.3s;
    }

    .qty-btn:hover {
        background: var(--primary-color);
        color: white;
    }

    .qty-input {
        width: 80px;
        height: 40px;
        text-align: center;
        border: 2px solid var(--border-color);
        border-radius: 4px;
        font-size: 1.125rem;
        font-weight: 500;
    }

    .action-buttons {
        display: flex;
        gap: 1rem;
        margin-top: 1rem;
    }

    .btn-large {
        flex: 2;
        font-size: 1.125rem;
    }

    @media (max-width: 768px) {
        .product-detail {
            grid-template-columns: 1fr;
            gap: 2rem;
            padding: 1.5rem;
        }

        .product-title {
            font-size: 1.5rem;
        }

        .product-price {
            font-size: 2rem;
        }

        .action-buttons {
            flex-direction: column;
        }

        .btn-large {
            width: 100%;
        }
    }
</style>