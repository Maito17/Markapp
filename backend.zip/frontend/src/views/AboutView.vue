<script setup>
    import { RouterLink } from 'vue-router'
</script>

<template>
    <div class="container">
        <div class="about-container">
            <header class="about-header">
                <h1>Acerca de MercApp</h1>
                <p class="subtitle">Tu tienda de tecnología en línea</p>
            </header>

            <div class="about-content">
                <section class="about-section">
                    <div class="section-icon">🛍️</div>
                    <h2>¿Qué es MercApp?</h2>
                    <p>
                        MercApp es una aplicación web de comercio electrónico desarrollada como proyecto
                        académico para la Universidad Politécnica Salesiana. Ofrece un catálogo completo
                        de productos tecnológicos con funcionalidades modernas y una experiencia de usuario
                        intuitiva.
                    </p>
                </section>

                <section class="about-section">
                    <div class="section-icon">⚡</div>
                    <h2>Características</h2>
                    <ul class="features-list">
                        <li>✅ Catálogo completo de productos</li>
                        <li>✅ Búsqueda y filtrado avanzado</li>
                        <li>✅ Carrito de compras persistente</li>
                        <li>✅ Gestión CRUD de productos</li>
                        <li>✅ Interfaz responsiva</li>
                        <li>✅ Navegación SPA fluida</li>
                    </ul>
                </section>

                <section class="about-section">
                    <div class="section-icon">🛠️</div>
                    <h2>Tecnologías Utilizadas</h2>
                    <div class="tech-grid">
                        <div class="tech-card">
                            <h3>Frontend</h3>
                            <ul>
                                <li>Vue 3 (Composition API)</li>
                                <li>Vue Router</li>
                                <li>Pinia (State Management)</li>
                                <li>Vite</li>
                            </ul>
                        </div>
                        <div class="tech-card">
                            <h3>Backend</h3>
                            <ul>
                                <li>Node.js</li>
                                <li>Express</li>
                                <li>REST API</li>
                                <li>CORS</li>
                            </ul>
                        </div>
                    </div>
                </section>

                <section class="about-section">
                    <div class="section-icon">🎓</div>
                    <h2>Proyecto Académico</h2>
                    <p>
                        Este proyecto fue desarrollado como parte de la asignatura "Aplicaciones Web"
                        en la Universidad Politécnica Salesiana, con el objetivo de aplicar los
                        conocimientos adquiridos sobre desarrollo web moderno, APIs REST y arquitecturas
                        de aplicaciones de una sola página (SPA).
                    </p>
                </section>

                <section class="about-section cta-section">
                    <h2>¿Listo para explorar?</h2>
                    <p>Descubre nuestro catálogo de productos y comienza a comprar</p>
                    <RouterLink to="/" class="btn btn-primary btn-large">
                        Ver Catálogo
                    </RouterLink>
                </section>
            </div>
        </div>
    </div>
</template>

<style scoped>
    .about-container {
        max-width: 900px;
        margin: 0 auto;
    }

    .about-header {
        text-align: center;
        margin-bottom: 3rem;
    }

    .about-header h1 {
        font-size: 3rem;
        color: var(--dark-color);
        margin-bottom: 1rem;
    }

    .subtitle {
        font-size: 1.25rem;
        color: #7f8c8d;
    }

    .about-content {
        display: flex;
        flex-direction: column;
        gap: 2.5rem;
    }

    .about-section {
        background: white;
        padding: 2.5rem;
        border-radius: 8px;
        box-shadow: var(--shadow);
    }

    .section-icon {
        font-size: 3rem;
        text-align: center;
        margin-bottom: 1rem;
    }

    .about-section h2 {
        font-size: 1.75rem;
        color: var(--dark-color);
        margin-bottom: 1.25rem;
        text-align: center;
    }

    .about-section p {
        font-size: 1.125rem;
        line-height: 1.8;
        color: #555;
        text-align: center;
    }

    .features-list {
        list-style: none;
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 1rem;
        padding: 0;
        margin-top: 1.5rem;
    }

    .features-list li {
        font-size: 1.125rem;
        padding: 0.75rem;
        background: var(--light-color);
        border-radius: 4px;
    }

    .tech-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 2rem;
        margin-top: 1.5rem;
    }

    .tech-card {
        background: var(--light-color);
        padding: 1.5rem;
        border-radius: 8px;
    }

    .tech-card h3 {
        font-size: 1.25rem;
        color: var(--primary-color);
        margin-bottom: 1rem;
        text-align: center;
    }

    .tech-card ul {
        list-style-position: inside;
        color: var(--dark-color);
    }

    .tech-card li {
        padding: 0.25rem 0;
    }

    .cta-section {
        background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
        color: white;
        text-align: center;
    }

    .cta-section h2 {
        color: white;
    }

    .cta-section p {
        color: white;
        margin-bottom: 1.5rem;
    }

    .btn-large {
        padding: 1rem 3rem;
        font-size: 1.25rem;
    }

    @media (max-width: 768px) {
        .about-header h1 {
            font-size: 2rem;
        }

        .about-section {
            padding: 1.5rem;
        }

        .features-list {
            grid-template-columns: 1fr;
        }

        .tech-grid {
            grid-template-columns: 1fr;
            gap: 1rem;
        }
    }
</style>