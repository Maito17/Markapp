<script setup>
import { ref, reactive, onMounted, computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useProducts, useCategories } from '../composables/useProducts'

const route = useRoute()
const router = useRouter()
const { getProduct, createProduct, updateProduct } = useProducts()
const { data: categories, getCategories } = useCategories()

const isEdit = computed(() => !!route.params.id)
const loading = ref(false)
const errors = ref([])

const form = reactive({
  name: '',
  description: '',
  price: 0,
  imageUrl: '',
  categoryId: '',
  stock: 0
})

onMounted(async () => {
  await getCategories()

  if (isEdit.value) {
    loading.value = true
    try {
      const product = await getProduct(route.params.id)
      form.name = product.name
      form.description = product.description
      form.price = product.price
      form.imageUrl = product.imageUrl
      form.categoryId = product.categoryId
      form.stock = product.stock
    } catch (err) {
      alert('Error al cargar el producto')
      router.push('/')
    } finally {
      loading.value = false
    }
  }
})

const validateForm = () => {
  errors.value = []
  if (!form.name || form.name.trim() === '') errors.value.push('El nombre es obligatorio')
  if (!form.price || form.price <= 0) errors.value.push('El precio debe ser mayor a 0')
  if (!form.categoryId) errors.value.push('La categoría es obligatoria')
  if (form.stock < 0) errors.value.push('El stock no puede ser negativo')
  if (form.imageUrl && !isValidUrl(form.imageUrl)) errors.value.push('La URL de la imagen no es válida')
  return errors.value.length === 0
}

const isValidUrl = (url) => {
  try {
    new URL(url)
    return true
  } catch {
    return false
  }
}

const handleSubmit = async () => {
  if (!validateForm()) return
  loading.value = true
  errors.value = []
  try {
    const productData = {
      name: form.name,
      description: form.description,
      price: parseFloat(form.price),
      imageUrl: form.imageUrl || 'https://via.placeholder.com/400',
      categoryId: parseInt(form.categoryId),
      stock: parseInt(form.stock) || 0
    }

    if (isEdit.value) {
      await updateProduct(route.params.id, productData)
      alert('Producto actualizado correctamente')
    } else {
      await createProduct(productData)
      alert('Producto creado correctamente')
    }

    router.push('/')
  } catch (err) {
    errors.value = ['Error al guardar el producto. Por favor, intenta nuevamente.']
  } finally {
    loading.value = false
  }
}
</script>

<template>
  <div class="container">
    <router-link to="/" class="back-link">← Volver al catálogo</router-link>

    <div class="form-container">
      <header class="form-header">
        <h1>{{ isEdit ? 'Editar Producto' : 'Nuevo Producto' }}</h1>
        <p>{{ isEdit ? 'Actualiza la información del producto' : 'Completa los datos del nuevo producto' }}</p>
      </header>

      <div v-if="errors.length > 0" class="error-alert">
        <h3>❌ Se encontraron los siguientes errores:</h3>
        <ul>
          <li v-for="(error, index) in errors" :key="index">{{ error }}</li>
        </ul>
      </div>

      <form @submit.prevent="handleSubmit" class="product-form">
        <div class="form-group">
          <label for="name" class="required">Nombre del producto</label>
          <input id="name" v-model="form.name" type="text" placeholder="Ej: Laptop HP Pavilion" class="form-input" required />
        </div>

        <div class="form-group">
          <label for="description">Descripción</label>
          <textarea id="description" v-model="form.description" placeholder="Describe las características del producto" rows="4" class="form-input"></textarea>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label for="price" class="required">Precio ($)</label>
            <input id="price" v-model.number="form.price" type="number" step="0.01" min="0.01" placeholder="0.00" class="form-input" required />
          </div>

          <div class="form-group">
            <label for="stock" class="required">Stock</label>
            <input id="stock" v-model.number="form.stock" type="number" min="0" placeholder="0" class="form-input" required />
          </div>
        </div>

        <div class="form-group">
          <label for="category" class="required">Categoría</label>
          <select id="category" v-model="form.categoryId" class="form-input" required>
            <option value="">Selecciona una categoría</option>
            <option v-for="category in categories" :key="category.id" :value="category.id">{{ category.name }}</option>
          </select>
        </div>

        <div class="form-group">
          <label for="imageUrl">URL de la imagen</label>
          <input id="imageUrl" v-model="form.imageUrl" type="url" placeholder="https://ejemplo.com/imagen.jpg" class="form-input" />
          <small class="form-help">Si no proporcionas una URL, se usará una imagen por defecto</small>
        </div>

        <div v-if="form.imageUrl" class="image-preview">
          <p>Vista previa:</p>
          <img :src="form.imageUrl" alt="Preview" @error="form.imageUrl = ''" />
        </div>

        <div class="form-actions">
          <button type="submit" class="btn btn-primary btn-large" :disabled="loading">{{ loading ? 'Guardando...' : (isEdit ? 'Actualizar Producto' : 'Crear Producto') }}</button>
          <router-link to="/" class="btn btn-outline">Cancelar</router-link>
        </div>
      </form>
    </div>
  </div>
</template>

<style scoped>
/* keep styles (unchanged) */
.back-link { display: inline-block; margin-bottom: 2rem; color: var(--primary-color); text-decoration: none; font-weight: 500; transition: transform 0.3s; }
.back-link:hover { transform: translateX(-5px); }
.form-container { max-width: 800px; margin: 0 auto; background: white; border-radius: 8px; padding: 2.5rem; box-shadow: var(--shadow); }
.form-header { text-align: center; margin-bottom: 2rem; }
.form-header h1 { font-size: 2rem; color: var(--dark-color); margin-bottom: 0.5rem; }
.form-header p { color: #7f8c8d; }
.error-alert { background: #fee; border: 2px solid var(--danger-color); border-radius: 8px; padding: 1.5rem; margin-bottom: 2rem; }
.error-alert h3 { color: var(--danger-color); margin-bottom: 1rem; font-size: 1.125rem; }
.error-alert ul { list-style-position: inside; color: var(--danger-color); }
.product-form { display: flex; flex-direction: column; gap: 1.5rem; }
.form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; }
.form-group { display: flex; flex-direction: column; gap: 0.5rem; }
.form-group label { font-weight: 600; color: var(--dark-color); font-size: 0.95rem; }
.form-group label.required::after { content: ' *'; color: var(--danger-color); }
.form-input { padding: 0.75rem 1rem; border: 2px solid var(--border-color); border-radius: 4px; font-size: 1rem; font-family: inherit; transition: border-color 0.3s; }
.form-input:focus { outline: none; border-color: var(--primary-color); }
.form-input::placeholder { color: #aaa; }
textarea.form-input { resize: vertical; min-height: 100px; }
.form-help { color: #7f8c8d; font-size: 0.875rem; }
.image-preview { display: flex; flex-direction: column; gap: 0.5rem; }
.image-preview p { font-weight: 500; color: var(--dark-color); }
.image-preview img { width: 100%; max-width: 400px; height: auto; border-radius: 8px; border: 2px solid var(--border-color); }
.form-actions { display: flex; gap: 1rem; margin-top: 1rem; }
.btn-large { flex: 1; font-size: 1.125rem; }
.btn:disabled { opacity: 0.6; cursor: not-allowed; }
@media (max-width: 768px) { .form-container { padding: 1.5rem; } .form-row { grid-template-columns: 1fr; } .form-actions { flex-direction: column; } }
</style>