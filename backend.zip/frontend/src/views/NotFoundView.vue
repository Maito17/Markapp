<script setup>
    import { RouterLink } from 'vue-router'
</script>

<template>
    <div class="container">
        <div class="not-found">
            <div class="error-code">404</div>
            <h1>Página no encontrada</h1>
            <p>Lo sentimos, la página que buscas no existe o ha sido movida.</p>

            <div class="actions">
                <RouterLink to="/" class="btn btn-primary">
                    🏠 Ir al inicio
                </RouterLink>
                <button @click="$router.back()" class="btn btn-outline">
                    ← Volver atrás
                </button>
            </div>

            <div class="illustration">
                🔍
            </div>
        </div>
    </div>
</template>

<style scoped>
    .not-found {
        text-align: center;
        padding: 4rem 2rem;
        background: white;
        border-radius: 8px;
        box-shadow: var(--shadow);
        max-width: 600px;
        margin: 0 auto;
    }

    .error-code {
        font-size: 8rem;
        font-weight: bold;
        color: var(--primary-color);
        line-height: 1;
        margin-bottom: 1rem;
        opacity: 0.2;
    }

    .not-found h1 {
        font-size: 2rem;
        color: var(--dark-color);
        margin-bottom: 1rem;
    }

    .not-found p {
        font-size: 1.125rem;
        color: #7f8c8d;
        margin-bottom: 2.5rem;
    }

    .actions {
        display: flex;
        gap: 1rem;
        justify-content: center;
        margin-bottom: 2rem;
    }

    .illustration {
        font-size: 5rem;
        opacity: 0.3;
        margin-top: 2rem;
    }

    @media (max-width: 768px) {
        .error-code {
            font-size: 5rem;
        }

        .not-found h1 {
            font-size: 1.5rem;
        }

        .actions {
            flex-direction: column;
        }
    }
</style>