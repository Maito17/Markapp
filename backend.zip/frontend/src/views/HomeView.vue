<script setup>
import { ref, computed, onMounted } from 'vue'
import { useProducts, useCategories } from '../composables/useProducts'
import { useCartStore } from '../stores/cart'
import ProductCard from '../components/ProductCard.vue'

const { data: products, loading: loadingProducts, error: errorProducts, getProducts } = useProducts()
const { data: categories, getCategories } = useCategories()
const cartStore = useCartStore()

const searchQuery = ref('')
const selectedCategory = ref('')

onMounted(async () => {
    await Promise.all([
        getProducts(),
        getCategories()
    ])
})

const filteredProducts = computed(() => {
    if (!products.value) return []

    let result = products.value

    // Filtrar por búsqueda
    if (searchQuery.value) {
        const query = searchQuery.value.toLowerCase()
        result = result.filter(product =>
            product.name.toLowerCase().includes(query) ||
            product.description.toLowerCase().includes(query)
        )
    }

    // Filtrar por categoría
    if (selectedCategory.value) {
        result = result.filter(product =>
            product.categoryId === parseInt(selectedCategory.value)
        )
    }

    return result
})

const handleAddToCart = (product) => {
    cartStore.addItem(product)
    alert(`${product.name} añadido al carrito`)
}

const clearFilters = () => {
    searchQuery.value = ''
    selectedCategory.value = ''
}
</script>

<template>
    <div class="container">
        <header class="page-header">
            <h1>Catálogo de Productos</h1>
            <p>Encuentra los mejores productos de tecnología</p>
        </header>

        <!-- Filtros y búsqueda -->
        <div class="filters">
            <div class="search-box">
                <input v-model="searchQuery" type="text" placeholder="🔍 Buscar productos..." class="search-input" />
            </div>

            <div class="filter-group">
                <label for="category">Categoría:</label>
                <select id="category" v-model="selectedCategory" class="filter-select">
                    <option value="">Todas las categorías</option>
                    <option v-for="category in categories" :key="category.id" :value="category.id">
                        {{ category.name }}
                    </option>
                </select>
            </div>
        </div>

        <!-- Estado de carga -->
        <div v-if="loadingProducts" class="loading-container">
            <div class="spinner"></div>
            <p>Cargando productos...</p>
        </div>

        <!-- Error -->
        <div v-else-if="errorProducts" class="error-message">
            <p>❌ {{ errorProducts }}</p>
            <button @click="getProducts" class="btn btn-primary">
                Reintentar
            </button>
        </div>

        <!-- Lista de productos -->
        <div v-else-if="filteredProducts.length > 0" class="products-grid">
            <ProductCard v-for="product in filteredProducts" :key="product.id" :product="product"
                @add-to-cart="handleAddToCart" />
        </div>

        <!-- Sin resultados -->
        <div v-else class="empty-state">
            <p>😔 No se encontraron productos</p>
            <button v-if="searchQuery || selectedCategory" @click="clearFilters()"
                class="btn btn-outline">
                Limpiar filtros
            </button>
        </div>
    </div>
</template>

<style scoped>
    .page-header {
        text-align: center;
        margin-bottom: 3rem;
    }

    .page-header h1 {
        font-size: 2.5rem;
        color: var(--dark-color);
        margin-bottom: 0.5rem;
    }

    .page-header p {
        font-size: 1.125rem;
        color: #7f8c8d;
    }

    .filters {
        display: flex;
        gap: 1rem;
        margin-bottom: 2rem;
        flex-wrap: wrap;
        background: white;
        padding: 1.5rem;
        border-radius: 8px;
        box-shadow: var(--shadow);
    }

    .search-box {
        flex: 1;
        min-width: 250px;
    }

    .search-input {
        width: 100%;
        padding: 0.75rem 1rem;
        border: 2px solid var(--border-color);
        border-radius: 4px;
        font-size: 1rem;
        transition: border-color 0.3s;
    }

    .search-input:focus {
        outline: none;
        border-color: var(--primary-color);
    }

    .filter-group {
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .filter-group label {
        font-weight: 500;
        color: var(--dark-color);
    }

    .filter-select {
        padding: 0.75rem 1rem;
        border: 2px solid var(--border-color);
        border-radius: 4px;
        font-size: 1rem;
        cursor: pointer;
        transition: border-color 0.3s;
    }

    .filter-select:focus {
        outline: none;
        border-color: var(--primary-color);
    }

    .products-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
        gap: 2rem;
        margin-bottom: 2rem;
    }

    .error-message {
        text-align: center;
        padding: 3rem;
        background: white;
        border-radius: 8px;
        box-shadow: var(--shadow);
    }

    .error-message p {
        font-size: 1.25rem;
        color: var(--danger-color);
        margin-bottom: 1rem;
    }

    .empty-state {
        text-align: center;
        padding: 3rem;
        background: white;
        border-radius: 8px;
        box-shadow: var(--shadow);
    }

    .empty-state p {
        font-size: 1.25rem;
        color: #7f8c8d;
        margin-bottom: 1rem;
    }

    @media (max-width: 768px) {
        .page-header h1 {
            font-size: 2rem;
        }

        .filters {
            flex-direction: column;
        }

        .products-grid {
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 1.5rem;
        }
    }
</style>
