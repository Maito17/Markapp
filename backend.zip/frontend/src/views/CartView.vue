<script setup>
    import { RouterLink } from 'vue-router'
    import { useCartStore } from '../stores/cart'

    const cartStore = useCartStore()

    const updateQuantity = (itemId, newQuantity) => {
        if (newQuantity > 0) {
            cartStore.updateQuantity(itemId, parseInt(newQuantity))
        }
    }

    const removeItem = (itemId) => {
        if (confirm('¿Deseas eliminar este producto del carrito?')) {
            cartStore.removeItem(itemId)
        }
    }

    const handleCheckout = () => {
        alert(`Procesando compra de ${cartStore.totalItems} productos por $${cartStore.totalPrice.toFixed(2)}`)
        cartStore.clearCart()
    }
</script>

<template>
    <div class="container">
        <header class="page-header">
            <h1>🛒 Carrito de Compras</h1>
        </header>

        <div v-if="cartStore.items.length === 0" class="empty-cart">
            <div class="empty-icon">🛒</div>
            <h2>Tu carrito está vacío</h2>
            <p>Agrega productos para comenzar a comprar</p>
            <RouterLink to="/" class="btn btn-primary">
                Ir al catálogo
            </RouterLink>
        </div>

        <div v-else class="cart-content">
            <div class="cart-items">
                <div v-for="item in cartStore.items" :key="item.id" class="cart-item">
                    <RouterLink :to="`/product/${item.id}`" class="item-image">
                        <img :src="item.imageUrl" :alt="item.name" />
                    </RouterLink>

                    <div class="item-details">
                        <RouterLink :to="`/product/${item.id}`" class="item-name">
                            {{ item.name }}
                        </RouterLink>
                        <div class="item-price">${{ item.price.toFixed(2) }} c/u</div>
                    </div>

                    <div class="item-quantity">
                        <label>Cantidad:</label>
                        <input type="number" :value="item.quantity"
                            @change="updateQuantity(item.id, $event.target.value)" min="1" class="quantity-input" />
                    </div>

                    <div class="item-total">
                        <div class="total-label">Subtotal:</div>
                        <div class="total-price">${{ (item.price * item.quantity).toFixed(2) }}</div>
                    </div>

                    <button @click="removeItem(item.id)" class="remove-btn" title="Eliminar">
                        🗑️
                    </button>
                </div>
            </div>

            <div class="cart-summary">
                <h2>Resumen del Pedido</h2>

                <div class="summary-row">
                    <span>Productos:</span>
                    <span>{{ cartStore.totalItems }}</span>
                </div>

                <div class="summary-row total-row">
                    <span>Total:</span>
                    <span class="total-amount">${{ cartStore.totalPrice.toFixed(2) }}</span>
                </div>

                <button @click="handleCheckout" class="btn btn-primary btn-block">
                    Proceder al pago
                </button>

                <button @click="cartStore.clearCart" class="btn btn-outline btn-block">
                    Vaciar carrito
                </button>

                <RouterLink to="/" class="continue-shopping">
                    ← Continuar comprando
                </RouterLink>
            </div>
        </div>
    </div>
</template>

<style scoped>
    .page-header {
        text-align: center;
        margin-bottom: 3rem;
    }

    .page-header h1 {
        font-size: 2.5rem;
        color: var(--dark-color);
    }

    .empty-cart {
        text-align: center;
        padding: 4rem 2rem;
        background: white;
        border-radius: 8px;
        box-shadow: var(--shadow);
    }

    .empty-icon {
        font-size: 5rem;
        margin-bottom: 1rem;
        opacity: 0.3;
    }

    .empty-cart h2 {
        font-size: 1.75rem;
        color: var(--dark-color);
        margin-bottom: 0.5rem;
    }

    .empty-cart p {
        color: #7f8c8d;
        margin-bottom: 2rem;
    }

    .cart-content {
        display: grid;
        grid-template-columns: 2fr 1fr;
        gap: 2rem;
    }

    .cart-items {
        display: flex;
        flex-direction: column;
        gap: 1rem;
    }

    .cart-item {
        display: grid;
        grid-template-columns: 100px 2fr 150px 150px auto;
        gap: 1.5rem;
        align-items: center;
        background: white;
        padding: 1.5rem;
        border-radius: 8px;
        box-shadow: var(--shadow);
    }

    .item-image {
        width: 100px;
        height: 100px;
        border-radius: 8px;
        overflow: hidden;
    }

    .item-image img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.3s;
    }

    .item-image:hover img {
        transform: scale(1.1);
    }

    .item-details {
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
    }

    .item-name {
        font-size: 1.125rem;
        font-weight: 600;
        color: var(--dark-color);
        text-decoration: none;
        transition: color 0.3s;
    }

    .item-name:hover {
        color: var(--primary-color);
    }

    .item-price {
        color: #7f8c8d;
    }

    .item-quantity {
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
    }

    .item-quantity label {
        font-size: 0.875rem;
        font-weight: 500;
        color: #7f8c8d;
    }

    .quantity-input {
        width: 100%;
        padding: 0.5rem;
        border: 2px solid var(--border-color);
        border-radius: 4px;
        font-size: 1rem;
        text-align: center;
    }

    .item-total {
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
        text-align: right;
    }

    .total-label {
        font-size: 0.875rem;
        color: #7f8c8d;
    }

    .total-price {
        font-size: 1.25rem;
        font-weight: bold;
        color: var(--secondary-color);
    }

    .remove-btn {
        background: none;
        border: none;
        font-size: 1.5rem;
        cursor: pointer;
        padding: 0.5rem;
        transition: transform 0.3s;
    }

    .remove-btn:hover {
        transform: scale(1.2);
    }

    .cart-summary {
        background: white;
        padding: 2rem;
        border-radius: 8px;
        box-shadow: var(--shadow);
        height: fit-content;
        position: sticky;
        top: 100px;
    }

    .cart-summary h2 {
        font-size: 1.5rem;
        margin-bottom: 1.5rem;
        color: var(--dark-color);
    }

    .summary-row {
        display: flex;
        justify-content: space-between;
        padding: 1rem 0;
        border-bottom: 1px solid var(--light-color);
    }

    .total-row {
        border-bottom: none;
        padding-top: 1.5rem;
        margin-top: 1rem;
        border-top: 2px solid var(--dark-color);
        font-size: 1.25rem;
        font-weight: bold;
    }

    .total-amount {
        color: var(--secondary-color);
        font-size: 1.75rem;
    }

    .btn-block {
        width: 100%;
        margin-top: 1rem;
    }

    .continue-shopping {
        display: block;
        text-align: center;
        margin-top: 1.5rem;
        color: var(--primary-color);
        text-decoration: none;
        font-weight: 500;
    }

    .continue-shopping:hover {
        text-decoration: underline;
    }

    @media (max-width: 1024px) {
        .cart-content {
            grid-template-columns: 1fr;
        }

        .cart-summary {
            position: static;
        }
    }

    @media (max-width: 768px) {
        .cart-item {
            grid-template-columns: 80px 1fr;
            gap: 1rem;
        }

        .item-image {
            width: 80px;
            height: 80px;
        }

        .item-quantity,
        .item-total {
            grid-column: 2;
        }

        .remove-btn {
            grid-column: 2;
            justify-self: end;
        }
    }
</style>