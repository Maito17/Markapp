<script setup>
import { RouterLink, RouterView } from 'vue-router'
import { useCartStore } from './stores/cart'

const cartStore = useCartStore()
</script>

<template>
    <div id="app">
        <nav class="navbar">
            <div class="container">
                <RouterLink to="/" class="logo">
                    🛍️ MercApp
                </RouterLink>

                <div class="nav-links">
                    <RouterLink to="/" class="nav-link">Inicio</RouterLink>
                    <RouterLink to="/product/new" class="nav-link">Nuevo Producto</RouterLink>
                    <RouterLink to="/about" class="nav-link">Acerca de</RouterLink>
                    <RouterLink to="/cart" class="nav-link cart-link">
                        🛒 Carrito
                        <span v-if="cartStore.totalItems > 0" class="badge">
                            {{ cartStore.totalItems }}
                        </span>
                    </RouterLink>
                </div>
            </div>
        </nav>

        <main class="main-content">
            <Suspense>
                <template #default>
                    <RouterView />
                </template>
                <template #fallback>
                    <div class="loading-container">
                        <div class="spinner"></div>
                        <p>Cargando...</p>
                    </div>
                </template>
            </Suspense>
        </main>

        <footer class="footer">
            <div class="container">
                <p>&copy; 2024 MercApp - Universidad Politécnica Salesiana</p>
            </div>
        </footer>
    </div>
</template>

<style>
:root {
    --primary-color: #3498db;
    --secondary-color: #2ecc71;
    --danger-color: #e74c3c;
    --dark-color: #2c3e50;
    --light-color: #ecf0f1;
    --border-color: #bdc3c7;
    --shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
    line-height: 1.6;
    color: var(--dark-color);
    background-color: #f5f7fa;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px;
}

.navbar {
    background: white;
    box-shadow: var(--shadow);
    position: sticky;
    top: 0;
    z-index: 100;
}

.navbar .container {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 1rem 20px;
}

.logo {
    font-size: 1.5rem;
    font-weight: bold;
    color: var(--primary-color);
    text-decoration: none;
}

.nav-links {
    display: flex;
    gap: 2rem;
    align-items: center;
}

.nav-link {
    text-decoration: none;
    color: var(--dark-color);
    font-weight: 500;
    transition: color 0.3s;
    position: relative;
}

.nav-link:hover {
    color: var(--primary-color);
}

.nav-link.router-link-active {
    color: var(--primary-color);
}

.cart-link {
    position: relative;
}

.badge {
    position: absolute;
    top: -8px;
    right: -12px;
    background: var(--danger-color);
    color: white;
    border-radius: 50%;
    width: 20px;
    height: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0.75rem;
    font-weight: bold;
}

.main-content {
    min-height: calc(100vh - 140px);
    padding: 2rem 0;
}

.footer {
    background: var(--dark-color);
    color: white;
    text-align: center;
    padding: 2rem 0;
    margin-top: 3rem;
}

.loading-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    min-height: 400px;
}

.spinner {
    border: 4px solid var(--light-color);
    border-top: 4px solid var(--primary-color);
    border-radius: 50%;
    width: 50px;
    height: 50px;
    animation: spin 1s linear infinite;
}

@keyframes spin {
    0% {
        transform: rotate(0deg);
    }

    100% {
        transform: rotate(360deg);
    }
}

.btn {
    padding: 0.75rem 1.5rem;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 1rem;
    font-weight: 500;
    transition: all 0.3s;
    text-decoration: none;
    display: inline-block;
}

.btn-primary {
    background: var(--primary-color);
    color: white;
}

.btn-primary:hover {
    background: #2980b9;
    transform: translateY(-2px);
}

.btn-secondary {
    background: var(--secondary-color);
    color: white;
}

.btn-danger {
    background: var(--danger-color);
    color: white;
}

.btn-outline {
    background: transparent;
    border: 2px solid var(--primary-color);
    color: var(--primary-color);
}

@media (max-width: 768px) {
    .nav-links {
        gap: 1rem;
        font-size: 0.9rem;
    }

    .logo {
        font-size: 1.25rem;
    }
}
</style>