import { ref } from 'vue'

// Default to the current host with port 3000 so the frontend works when
// accessed via localhost or the LAN IP (e.g. 192.168.0.100).
const API_BASE = import.meta.env.VITE_API_BASE || `${location.protocol}//${location.hostname}:3000`

export function useProducts() {
	const data = ref([])
	const loading = ref(false)
	const error = ref(null)

	const getProducts = async () => {
		loading.value = true
		error.value = null
		try {
			const res = await fetch(`${API_BASE}/api/products`)
			if (!res.ok) throw new Error('HTTP ' + res.status)
			data.value = await res.json()
		} catch (e) {
			error.value = e.message || 'Error al obtener productos'
		} finally {
			loading.value = false
		}
	}

	const getProduct = async (id) => {
		const res = await fetch(`${API_BASE}/api/products/${id}`)
		if (!res.ok) throw new Error('Producto no encontrado')
		return await res.json()
	}

	const createProduct = async (product) => {
		const res = await fetch(`${API_BASE}/api/products`, {
			method: 'POST',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify(product)
		})
		if (!res.ok) {
			const body = await res.json().catch(()=>({}))
			throw new Error(body.error || 'Error al crear producto')
		}
		const created = await res.json()
		data.value.push(created)
		return created
	}

	const updateProduct = async (id, product) => {
		const res = await fetch(`${API_BASE}/api/products/${id}`, {
			method: 'PUT',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify(product)
		})
		if (!res.ok) {
			const body = await res.json().catch(()=>({}))
			throw new Error(body.error || 'Error al actualizar producto')
		}
		const updated = await res.json()
		const idx = data.value.findIndex(p => p.id === updated.id)
		if (idx !== -1) data.value[idx] = updated
		return updated
	}

	const deleteProduct = async (id) => {
		const res = await fetch(`${API_BASE}/api/products/${id}`, { method: 'DELETE' })
		if (!res.ok) throw new Error('Error al borrar producto')
		data.value = data.value.filter(p => p.id !== Number(id))
		return true
	}

	return {
		data,
		loading,
		error,
		getProducts,
		getProduct,
		createProduct,
		updateProduct,
		deleteProduct
	}
}

export function useCategories() {
	const data = ref([])

	const getCategories = async () => {
		try {
			const res = await fetch(`${API_BASE}/api/categories`)
			if (!res.ok) throw new Error('HTTP ' + res.status)
			data.value = await res.json()
		} catch (e) {
			// fallback static list if backend not available
			data.value = [
				{ id: 1, name: 'Electrónica' },
				{ id: 2, name: 'Accesorios' },
				{ id: 3, name: 'Hogar' }
			]
		}
	}

	return { data, getCategories }
}

