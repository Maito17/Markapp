<template>
	<div class="product-card">
		<router-link :to="`/product/${product.id}`" class="image-wrap">
			<img :src="product.imageUrl || '/placeholder.png'" :alt="product.name" />
		</router-link>
		<div class="content">
			<h3 class="title">{{ product.name }}</h3>
			<p class="price">${{ Number(product.price).toFixed(2) }}</p>
			<p class="desc">{{ truncatedDescription }}</p>
		</div>
		<div class="actions">
			<button @click.prevent="onAdd" class="btn">Agregar</button>
		</div>
	</div>
</template>

<script>
export default {
	name: 'ProductCard',
	props: {
		product: { type: Object, required: true }
	},
	emits: ['add-to-cart', 'add'],
	computed: {
		truncatedDescription() {
			if (!this.product.description) return ''
			return this.product.description.length > 80
				? this.product.description.slice(0, 77) + '...'
				: this.product.description
		}
	},
	methods: {
		onAdd() {
			this.$emit('add-to-cart', this.product)
			this.$emit('add', this.product)
		}
	}
}
</script>

<style scoped>
.product-card { border: 1px solid #e5e7eb; padding: 12px; border-radius: 8px; display:flex; flex-direction:column; gap:8px }
.image-wrap { display:block; text-align:center }
.image-wrap img { max-width:100%; height:140px; object-fit:cover; border-radius:6px }
.title { margin:0; font-size:1.05rem }
.price { color:#0f172a; font-weight:600; margin:4px 0 }
.desc { color:#475569; font-size:0.9rem }
.actions { display:flex; justify-content:flex-end }
.btn { background:#0ea5e9; color:white; border:none; padding:6px 10px; border-radius:6px; cursor:pointer }
</style>
