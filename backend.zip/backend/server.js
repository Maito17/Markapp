// server.js
const express = require('express');
const cors = require('cors');
const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(express.json());

// Base de datos en memoria
let products = [
    {
        id: 1,
        name: "Laptop HP Pavilion",
        description: "Laptop con procesador Intel i5, 8GB RAM, 256GB SSD",
        price: 799.99,
        imageUrl: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=400",
        categoryId: 1,
        stock: 15
    },
    {
        id: 2,
        name: "Mouse Logitech MX Master",
        description: "Mouse inalámbrico ergonómico con sensor de alta precisión",
        price: 99.99,
        imageUrl: "https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?w=400",
        categoryId: 2,
        stock: 30
    },
    {
        id: 3,
        name: "Teclado Mecánico RGB",
        description: "Teclado mecánico con iluminación RGB y switches Cherry MX",
        price: 149.99,
        imageUrl: "https://images.unsplash.com/photo-1595225476474-87563907a212?w=400",
        categoryId: 2,
        stock: 20
    },
    {
        id: 4,
        name: "Monitor Samsung 27\"",
        description: "Monitor Full HD IPS de 27 pulgadas con 75Hz",
        price: 299.99,
        imageUrl: "https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?w=400",
        categoryId: 1,
        stock: 12
    },
    {
        id: 5,
        name: "Auriculares Sony WH-1000XM4",
        description: "Auriculares inalámbricos con cancelación de ruido activa",
        price: 349.99,
        imageUrl: "https://images.unsplash.com/photo-1546435770-a3e426bf472b?w=400",
        categoryId: 3,
        stock: 25
    },
    {
        id: 6,
        name: "Webcam Logitech C920",
        description: "Webcam Full HD 1080p con micrófono estéreo",
        price: 79.99,
        imageUrl: "https://images.unsplash.com/photo-1587826080692-f439cd0b70da?w=400",
        categoryId: 2,
        stock: 18
    },
    {
        id: 7,
        name: "SSD Samsung 1TB",
        description: "Disco SSD NVMe M.2 de 1TB con velocidades de hasta 3500MB/s",
        price: 129.99,
        imageUrl: "https://images.unsplash.com/photo-1531492746076-161ca9bcad58?w=400",
        categoryId: 4,
        stock: 40
    },
    {
        id: 8,
        name: "Router TP-Link AX3000",
        description: "Router WiFi 6 de doble banda con velocidades de hasta 3Gbps",
        price: 159.99,
        imageUrl: "https://images.unsplash.com/photo-1606904825846-647eb07f5be2?w=400",
        categoryId: 5,
        stock: 22
    },
    {
        id: 9,
        name: "Tablet iPad Air",
        description: "Tablet de 10.9 pulgadas con chip M1 y 256GB",
        price: 649.99,
        imageUrl: "https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=400",
        categoryId: 1,
        stock: 10
    },
    {
        id: 10,
        name: "Hub USB-C 7 en 1",
        description: "Hub multipuerto con HDMI, USB 3.0 y lector de tarjetas",
        price: 45.99,
        imageUrl: "https://images.unsplash.com/photo-1625948515291-69613efd103f?w=400",
        categoryId: 2,
        stock: 50
    }
];

let categories = [
    { id: 1, name: "Computadoras" },
    { id: 2, name: "Periféricos" },
    { id: 3, name: "Audio" },
    { id: 4, name: "Almacenamiento" },
    { id: 5, name: "Redes" }
];

let nextProductId = 11;

// Validación de productos
const validateProduct = (product, isUpdate = false) => {
    const errors = [];

    if (!isUpdate && !product.name) {
        errors.push("El nombre es obligatorio");
    }
    if (product.name && typeof product.name !== 'string') {
        errors.push("El nombre debe ser una cadena de texto");
    }
    if (product.price !== undefined && (typeof product.price !== 'number' || product.price <= 0)) {
        errors.push("El precio debe ser un número mayor a 0");
    }
    if (!isUpdate && product.price === undefined) {
        errors.push("El precio es obligatorio");
    }
    if (product.categoryId !== undefined && !categories.find(c => c.id === product.categoryId)) {
        errors.push("La categoría no existe");
    }
    if (!isUpdate && !product.categoryId) {
        errors.push("La categoría es obligatoria");
    }
    if (product.stock !== undefined && (typeof product.stock !== 'number' || product.stock < 0)) {
        errors.push("El stock debe ser un número mayor o igual a 0");
    }
    if (product.imageUrl && typeof product.imageUrl !== 'string') {
        errors.push("La URL de la imagen debe ser una cadena de texto");
    }

    return errors;
};

// Rutas de productos
app.get('/api/products', (req, res) => {
    try {
        res.json(products);
    } catch (error) {
        res.status(500).json({ error: 'Error al obtener productos' });
    }
});

app.get('/api/products/:id', (req, res) => {
    try {
        const id = parseInt(req.params.id);
        const product = products.find(p => p.id === id);

        if (!product) {
            return res.status(404).json({ error: 'Producto no encontrado' });
        }

        res.json(product);
    } catch (error) {
        res.status(500).json({ error: 'Error al obtener el producto' });
    }
});

app.get('/api/products/:id', (req, res) => {
    try {
        const id = parseInt(req.params.id);
        const product = products.find(p => p.id === id);

        if (!product) {
            return res.status(404).json({ error: 'Producto no encontrado' });
        }

        res.json(product);
    } catch (error) {
        res.status(500).json({ error: 'Error al obtener el producto' });
    }
});

app.post('/api/products', (req, res) => {
    try {
        const errors = validateProduct(req.body);

        if (errors.length > 0) {
            return res.status(400).json({ errors });
        }

        const newProduct = {
            id: nextProductId++,
            name: req.body.name,
            description: req.body.description || '',
            price: req.body.price,
            imageUrl: req.body.imageUrl || 'https://via.placeholder.com/400',
            categoryId: req.body.categoryId,
            stock: req.body.stock || 0
        };

        products.push(newProduct);
        res.status(201).json(newProduct);
    } catch (error) {
        res.status(500).json({ error: 'Error al crear el producto' });
    }
});

app.put('/api/products/:id', (req, res) => {
    try {
        const id = parseInt(req.params.id);
        const index = products.findIndex(p => p.id === id);

        if (index === -1) {
            return res.status(404).json({ error: 'Producto no encontrado' });
        }

        const errors = validateProduct(req.body, true);

        if (errors.length > 0) {
            return res.status(400).json({ errors });
        }

        const updatedProduct = {
            ...products[index],
            ...req.body,
            id: id
        };

        products[index] = updatedProduct;
        res.json(updatedProduct);
    } catch (error) {
        res.status(500).json({ error: 'Error al actualizar el producto' });
    }
});

app.put('/api/products/:id', (req, res) => {
    try {
        const id = parseInt(req.params.id);
        const index = products.findIndex(p => p.id === id);

        if (index === -1) {
            return res.status(404).json({ error: 'Producto no encontrado' });
        }

        const errors = validateProduct(req.body, true);

        if (errors.length > 0) {
            return res.status(400).json({ errors });
        }

        const updatedProduct = {
            ...products[index],
            ...req.body,
            id: id
        };

        products[index] = updatedProduct;
        res.json(updatedProduct);
    } catch (error) {
        res.status(500).json({ error: 'Error al actualizar el producto' });
    }
});

app.patch('/api/products/:id', (req, res) => {
    try {
        const id = parseInt(req.params.id);
        const index = products.findIndex(p => p.id === id);

        if (index === -1) {
            return res.status(404).json({ error: 'Producto no encontrado' });
        }

        const errors = validateProduct(req.body, true);

        if (errors.length > 0) {
            return res.status(400).json({ errors });
        }

        products[index] = { ...products[index], ...req.body, id };
        res.json(products[index]);
    } catch (error) {
        res.status(500).json({ error: 'Error al actualizar el producto' });
    }
});

app.delete('/api/products/:id', (req, res) => {
    try {
        const id = parseInt(req.params.id);
        const index = products.findIndex(p => p.id === id);

        if (index === -1) {
            return res.status(404).json({ error: 'Producto no encontrado' });
        }

        products.splice(index, 1);
        res.status(204).send();
    } catch (error) {
        res.status(500).json({ error: 'Error al eliminar el producto' });
    }
});

// Rutas de categorías
app.get('/api/categories', (req, res) => {
    try {
        res.json(categories);
    } catch (error) {
        res.status(500).json({ error: 'Error al obtener categorías' });
    }
});

// Manejo de rutas no encontradas
app.use((req, res) => {
    res.status(404).json({ error: 'Ruta no encontrada' });
});

// Inicio del servidor
app.listen(PORT, () => {
    console.log(`🚀 Servidor corriendo en http://localhost:${PORT}`);
    console.log(`📦 API disponible en http://localhost:${PORT}/api`);
});
